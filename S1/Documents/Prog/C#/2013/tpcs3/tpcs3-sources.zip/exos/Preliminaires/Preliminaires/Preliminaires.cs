﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Preliminaires
{
    class Preliminaires
    {
        static void Main(string[] args)
        {
        }
    }
}

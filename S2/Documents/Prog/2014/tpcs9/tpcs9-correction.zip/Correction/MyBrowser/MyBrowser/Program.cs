﻿using System;
using System.IO;
using System.Net.Sockets;

namespace MyBrowser
{
    class Program
    {
        static void Main(string[] args)
        {
            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            sock.Connect(args[0], 80);
            StreamWriter stw = new StreamWriter(new NetworkStream(sock));
            stw.Write("GET /~deabre_p/browser_test HTTP/1.1\nHost : " + args[0] + "\nConnection : close\n\n");
            stw.Flush();
            StreamReader str = new StreamReader(new NetworkStream(sock));
            Console.WriteLine(str.ReadToEnd());
            Console.Read();
        }
    }
}

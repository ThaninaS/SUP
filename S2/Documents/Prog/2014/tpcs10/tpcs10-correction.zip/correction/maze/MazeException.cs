﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace maze
{
    class MazeException : Exception
    {
        public MazeException()
        { 
        }

        public MazeException(string msg)
            : base(msg)
        {
        }
    }
}

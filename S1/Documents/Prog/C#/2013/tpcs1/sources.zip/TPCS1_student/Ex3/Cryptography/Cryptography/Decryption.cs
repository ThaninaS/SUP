﻿namespace Cryptography
{
    static class Decryption
    {
        public static uint MyFunc1(char original, char encrypted)
        {
            // FIXME
        }

        public static char MyFunc2(char encrypted, uint n)
        {
            // FIXME
        }
    }
}

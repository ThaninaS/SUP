﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace maze
{
    class Program
    {
        static void Main(string[] args)
        {
            bool ok = false;
            while (!ok)
            {
                try
                {
                    Console.Write("Choose its width : ");
                    int width = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Choose its height : ");
                    int height = Convert.ToInt32(Console.ReadLine());

                    Maze m = new Maze(width, height);
                    m.generate();
                    Console.WriteLine("Here your maze.");
                    m.print();
                    Console.WriteLine("Too difficult? Let me help. Press enter.");
                    Console.ReadLine();
                    m.print(m.solve());
                    Console.ReadLine();
                    ok = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}

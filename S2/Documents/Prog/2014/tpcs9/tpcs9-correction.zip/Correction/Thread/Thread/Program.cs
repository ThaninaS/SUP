﻿using System;
using System.Threading;

namespace ThreadConsole
{
    class Program
    {
        public static void Write1()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write("Thread 1");
            }
        }

        public static void Write2()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.Write("Thread 2");
            }
        }

        static void Main(string[] args)
        {
            Thread thread1 = new Thread(new ThreadStart(Write1));
            Thread thread2 = new Thread(new ThreadStart(Write2));

            thread1.Start();
            thread2.Start();

            Console.Read();
        }
    }
}

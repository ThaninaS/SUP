﻿using System;
using System.Windows.Forms;

namespace ASCII
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            //AsciiCreator.Function.StepX = FIXME;
            //AsciiCreator.Function.StepY = FIXME;

            //AsciiCreator.Function.ToGrey = FIXME;
            //AsciiCreator.Function.ToAscii = FIXME;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AsciiCreator.AsciiCreator());
        }
    }
}
﻿using System.Drawing;

namespace ASCII
{
    static class Ascii
    {

        static public float MyFunc1(Color color)
        {
            // FIXME
        }

        static public char MyFunc2(float grey)
        {
            // FIXME
        }
    }
}

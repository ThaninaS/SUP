﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tables
{
    static class Fixme
    {
        /* Add your functions here. */
        public static bool Test(string left, string door, string right)
        {
            throw new NotImplementedException();
        }
    }
}

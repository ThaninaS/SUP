﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace calculatrice
{
    class Calculatrice
    {
        public static long Simple_operation(long operand1, char operation, long operand2)
        {
            /* FIXME */
            throw new NotImplementedException();
        }

        public static long Pow(int x, int n)
        {
            /* FIXME */
            throw new NotImplementedException();
        }

        public static double Fibo(uint n)
        {
            /* FIXME */
            throw new NotImplementedException();
        }

        public static double Factorial(uint n)
        {
            /* FIXME */
            throw new NotImplementedException();
        }

        public static double Sqrt(double n, double x)
        {
            /* FIXME */
            throw new NotImplementedException();
        }
    }
}

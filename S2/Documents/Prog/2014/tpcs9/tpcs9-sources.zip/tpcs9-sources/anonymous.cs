﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {

        static void Main(string[] args)
        {
            List<int> list = new List<int>(new int[] { 0, 2, 3, 5, 6, 7, 1, 2, 12, 15 });
            List<int> list2 = new List<int>(new int[] { 1, 23, 32, 15, 12, 5, 1, 2, 12, 15 });

            var list3 = list.Where(x => (x % 2) == 0);
            var list4 = list.Zip(list2, (x, y) => (x + y) / 2);
            int count = list.Count(x => (x % 3) != 0);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        /*
         * CORRECTION TP C#2
         */

        /// <summary>
        /// Ex 0
        /// </summary>
        static void HelloWorld()
        {
            Console.WriteLine("Hello World!");
        }

        /// <summary>
        /// Ex 1
        /// </summary>
        static void Echo()
        {
            string s = Console.ReadLine();
            Console.WriteLine(s);
        }

        /// <summary>
        /// Ex 2
        /// </summary>
        static void PrintRev(string s, int i)
        {
            if (i < s.Length)
            {
                PrintRev(s, i + 1);
                Console.Write(s[i]);
            }
        }

        static void Reverse()
        {
            string s = Console.ReadLine();
            PrintRev(s, 0);
            Console.Write("\n");
        }

        /// <summary>
        /// Ex 3
        /// </summary>
        static void Triforce()
        {
            Console.Title = "Triforce";
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("   /\\   \n  /__\\  \n /\\  /\\ \n/__\\/__\\\n"); // En une ligne, c'est mieux !
            Console.ResetColor();
        }

        /// <summary>
        /// Ex 4
        /// </summary>
        static void QCM(string question, string rep1, string rep2, string rep3, string rep4, int rep)
        {
            Console.WriteLine(question);
            Console.WriteLine("1) " + rep1);
            Console.WriteLine("2) " + rep2);
            Console.WriteLine("3) " + rep3);
            Console.WriteLine("4) " + rep4);
            try
            {
                int rep_u = Convert.ToInt32(Console.ReadLine());
                if (rep_u == rep)
                    Console.WriteLine("Good job bro!");
                else if (rep_u > 0 && rep_u < 5)
                    Console.WriteLine("You lose... The answer was " + rep + ".");
                else
                    Console.WriteLine("So counting is too hard, n00b...");
            }
            catch
            {
                Console.WriteLine("So counting is too hard, n00b...");
            }
        }

        // exemple pour QCM
        static void TestQCM()
        {
            QCM("Quelle est la différence entre un pigeon ?",
                "Les deux pattes, surtout la gauche",
                "Oui",
                "Obiwan Kenobi",
                "La réponse D",
                1);
        }

        /// <summary>
        /// Ex 5
        /// </summary>
        static void Morse(string s, int i = 0)
        {
            if (i < s.Length)
            {
                if (s[i] == '.')
                    Console.Beep(900, 150);
                else if (s[i] == '_')
                    Console.Beep(900, 450);
                else
                    System.Threading.Thread.Sleep(450);
                Morse(s, i + 1);
            }
        }

        static void Main(string[] args)
        {
            HelloWorld();
            Echo();
            Reverse();
            Triforce();
            TestQCM();
            Morse(".___ .____. ._ .. __ .  __ . ...  ._ _._. _.. _._.");
            Console.ReadLine();
        }
    }
}

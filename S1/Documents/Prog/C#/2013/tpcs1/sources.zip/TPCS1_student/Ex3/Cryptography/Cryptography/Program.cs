﻿using System.Windows.Forms;
using Crypto;

namespace Cryptography
{
    class Program
    {
        static void Main(string[] args)
        {
            //Crypto.Function.DecryptRot = FIXME;
            //Crypto.Function.DecryptionFunc = FIXME;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Decrypt());
        }
    }
}
